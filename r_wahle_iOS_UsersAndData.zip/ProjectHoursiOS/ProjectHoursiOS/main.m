//
//  main.m
//  ProjectHoursiOS
//
//  Created by Ryan Wahle on 10/2/14.
//  Copyright (c) 2014 Ryan Wahle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
