//
//  ProjectHoursTableViewCell.m
//  ProjectHoursiOS
//
//  Created by Ryan Wahle on 10/7/14.
//  Copyright (c) 2014 Ryan Wahle. All rights reserved.
//

#import "ProjectHoursTableViewCell.h"

@implementation ProjectHoursTableViewCell

@end
